CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `vista_csv` AS
    SELECT 
        `provincia`.`CODPROV` AS `CODPROV`,
        `provincia`.`NOMBRE_PROVINCIA` AS `NOMBRE`,
        ROUND(AVG(`encuestas`.`SONIDO`), 3) AS `MEDIA_SONIDO`,
        ROUND(AVG(`encuestas`.`IMAGEN`), 3) AS `MEDIA_IMAGEN`,
        ROUND(AVG(`encuestas`.`USABILIDAD`), 3) AS `MEDIA_USABILIDAD`,
        ROUND((((AVG(`encuestas`.`SONIDO`) + AVG(`encuestas`.`IMAGEN`)) + AVG(`encuestas`.`USABILIDAD`)) / 3),
                2) AS `TOTAL_MEDIA`
    FROM
        (`encuestas`
        JOIN `provincia` ON ((`encuestas`.`CODPROV` = `provincia`.`CODPROV`)))
    WHERE
        ((((`encuestas`.`SONIDO` + `encuestas`.`IMAGEN`) + `encuestas`.`USABILIDAD`) / 3) <= 6)
    GROUP BY `provincia`.`CODPROV`
    LIMIT 5