CREATE DEFINER=`root`@`localhost` FUNCTION `VALORACION`(S INT, I INT, U INT) RETURNS varchar(20) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
    DECLARE resultado VARCHAR(20);
    IF S >= I AND S >= U THEN
        SET resultado = 'Gana Sonido';
    ELSEIF I >= S AND I >= U THEN
        SET resultado = 'Gana Imagen';
    ELSEIF U >= S and U >= I THEN
        SET resultado = 'Gana Usabilidad';
    END IF;
    RETURN resultado;
END