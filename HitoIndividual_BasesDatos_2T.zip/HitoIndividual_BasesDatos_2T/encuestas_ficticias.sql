CREATE DEFINER=`root`@`localhost` PROCEDURE `ENCUESTAS_FICTICIAS`()
BEGIN
DECLARE contador_provincias int;
DECLARE contador_encuestas int;

DROP TABLE IF EXISTS ENCUESTAS;
CREATE TABLE ENCUESTAS(
ID_ENCUESTA INT PRIMARY KEY AUTO_INCREMENT,
CODPROV CHAR(2),
SONIDO INT NOT NULL,
IMAGEN INT NOT NULL,
USABILIDAD INT NOT NULL,
FOREIGN KEY(CODPROV) REFERENCES PROVINCIA(CODPROV)
);

set contador_provincias = 0;
set contador_encuestas = 0;
    start transaction;
while contador_provincias < 52 do
set contador_provincias= contador_provincias + 1;
        set contador_encuestas = 0;
while contador_encuestas < 10 do
insert into encuestas values(null, LPAD(contador_provincias, 2, '0'), RAND()*10, RAND()*10, RAND()*10);
set contador_encuestas = contador_encuestas + 1;
end while;
end while;
commit;        
END